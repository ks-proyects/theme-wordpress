<?php
function keysist_list_ofertas(){
    echo "funciona";
}