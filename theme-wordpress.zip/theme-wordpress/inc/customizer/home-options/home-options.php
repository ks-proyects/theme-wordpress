<?php
/*Seccio Configuracion*/

$keysist_customizer_configuracion_setting_file_path = keysist_file_directory('inc/customizer/home-options/home-configuracion.php');
require $keysist_customizer_configuracion_setting_file_path;
/*Home Admin Section*/
$keysist_customizer_home_course_file_path = keysist_file_directory('inc/customizer/home-options/home-admin.php');
require $keysist_customizer_home_course_file_path;
